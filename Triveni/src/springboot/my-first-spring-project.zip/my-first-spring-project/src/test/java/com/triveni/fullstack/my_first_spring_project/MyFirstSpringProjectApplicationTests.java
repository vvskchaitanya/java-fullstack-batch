package com.triveni.fullstack.my_first_spring_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
